int main(void)
{
  int x = 5;
  int r = 10;
  for (int i = 0; i < 42*x; i++) {
    int y = 5;
    r += y;
  }
  return 0;
};